CREATE PROCEDURE getScheduleTable(IN inputDate VARCHAR(20))
  BEGIN
	select * from `car_schedule_table` where start_time like CONCAT('%',`inputDate` ,'%') or end_time like CONCAT('%',`inputDate` ,'%');

END;
